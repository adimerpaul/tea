import{h as e,c as a}from"./index.24f167e8.js";const c=e("div",{class:"q-space"});var s=a({name:"QSpace",setup(){return()=>c}});export{s as Q};
