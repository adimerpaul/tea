import{h as e,c as a}from"./index.f95e9203.js";const c=e("div",{class:"q-space"});var s=a({name:"QSpace",setup(){return()=>c}});export{s as Q};
