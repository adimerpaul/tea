import{h as e,c as a}from"./index.94ea9476.js";const c=e("div",{class:"q-space"});var s=a({name:"QSpace",setup(){return()=>c}});export{s as Q};
