import{h as e,c as a}from"./index.cb357fad.js";const c=e("div",{class:"q-space"});var s=a({name:"QSpace",setup(){return()=>c}});export{s as Q};
