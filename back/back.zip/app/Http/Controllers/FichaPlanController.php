<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FichaPlanController extends Controller
{
    //
}
