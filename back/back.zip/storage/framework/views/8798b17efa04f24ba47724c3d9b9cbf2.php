<?php $__env->startSection('content'); ?>
    <?php echo $document->html; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layouts.pdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyectos\tea\back\resources\views/pdf/html.blade.php ENDPATH**/ ?>