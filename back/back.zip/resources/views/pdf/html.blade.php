@extends('pdf.layouts.pdf')

@section('content')
    {!! $document->html !!}
@endsection
